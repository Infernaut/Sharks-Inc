<?php
include "dbconnect.php";

$pempID = isset($_POST['EmpID']) ? $_POST['EmpID'] : '';
if (isset($_POST['searchrec'])) {

  $sql = "Select * from Employee where TEmpID ='$pempID'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
?>
    <table>

      <tr>
    <?php
    while ($row = $result->fetch_assoc()) {


      $hid = $row["TEmpID"];
      $hfn = $row["Tfn"];
      $hmn = $row["Tmn"];
      $hln = $row["Tln"];
      $hdid = $row["TdeptID"];
      $hrc = $row["Trankcode"];
    }
  } else {
    echo "<script>alert('ID Not found...')</script>";
  }
}
    ?>